

import 'package:flutter/material.dart';

 const BTNpink = Color.fromARGB(255, 241, 39, 100);
 const BTNgreen = Color.fromARGB(255, 73, 179, 105);
 const appbarGreen = Color.fromARGB(255, 76, 141, 95);