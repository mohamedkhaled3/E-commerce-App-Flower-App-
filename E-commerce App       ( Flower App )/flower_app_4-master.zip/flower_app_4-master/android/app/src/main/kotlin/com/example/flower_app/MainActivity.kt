package com.example.flower_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
