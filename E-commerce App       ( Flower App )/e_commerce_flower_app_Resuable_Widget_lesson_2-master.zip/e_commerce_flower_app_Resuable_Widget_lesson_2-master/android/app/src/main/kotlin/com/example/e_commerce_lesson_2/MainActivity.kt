package com.example.e_commerce_lesson_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
